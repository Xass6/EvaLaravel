<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
</head>
<div>
  lololo
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>