<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
Use App\Salle as Salle;


class View extends Controller
{
  public function showSalle()
  {
    $salle = Salle::all();
    return view ('Salles', ['salle' => $salle]);
  }
}
