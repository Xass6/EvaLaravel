<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Salle extends Model
{
      public function Lieux()
    {
      return $this->belongsToMany('App\Lieux');
    }
    public function Disponibilite()
    {
      return $this->belongsToMany('App\Disponibilite');
    }
}
