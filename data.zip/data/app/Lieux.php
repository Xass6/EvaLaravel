<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Lieux extends Model
{
  public function completeName()
  {
      return $this->name;
  }
}
