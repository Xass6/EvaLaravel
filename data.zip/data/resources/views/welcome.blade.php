
@extends('templates.header')

@section('title', 'Home')

@section('content')
</head>
<div>
  lololo
</div>
@endsection
