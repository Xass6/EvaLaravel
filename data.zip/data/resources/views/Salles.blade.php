
@extends('templates.header')

@section('title', 'Toute les salles')

@section('content')
  <p>Liste des salle :</p>
  <table>
  <tr>
      <th>Nom</th>
  </tr>
      @foreach( $salle as $salles )
          <tr>
          <td>{{ $salle->name }}</td>
          <td>
  </table>
@endsection
