<ul>
  <li><a class="menu" href="/">Accueil</a></li>
  <li><a class="menu" href="/Salles">Nos Salles</a></li>
</ul>
