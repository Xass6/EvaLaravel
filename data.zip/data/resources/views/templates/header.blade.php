
<html>
    <head>
        <title>Concert - @yield('title')</title>
        <link rel="stylesheet"  href="{{ asset('./css/style.css') }}">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
      <header>
          @include('./templates.sidebar')
      </header>
        <main>
            @yield('content')
        </main>
    </body>
    <script type="text/javascript" src="{{ asset('./js/script.js') }}"></script>
</html>
