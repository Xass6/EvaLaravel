<?php

use Illuminate\Database\Seeder;

class SalleTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      DB::table('salle')->insert(
    [
      [
        "name" => "Le Tranbordeur",
        "lieux_id" => "1",
        "disponibilite_id" => "1",
      ]
    ]
);
    }
}
