<?php

use Illuminate\Database\Seeder;

class LieuxTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      DB::table('lieux')->insert(
    [
      [
        "name" => "Villeurbanne",
      ],
      [
        "name" => "Lyon",
      ],
      [
        "name" => "Paris",
      ],
      [
        "name" => "Strasbourg",
      ],
      [
        "name" => "Nimes",
      ],
      [
        "name" => "Toulouse",
      ],
    ]
);
    }
}
