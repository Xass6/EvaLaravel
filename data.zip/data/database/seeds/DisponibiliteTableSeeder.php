<?php

use Illuminate\Database\Seeder;

class DisponibiliteTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      DB::table('Disponibilite')->insert(
    [
      [
        "name" => "Libre",
      ],
      [
        "name" => "Réserver",
      ],
    ]
);
    }
}
